mvn install:install-file -Dfile=HtmlTablePanel.jar -DgroupId=nullfish -DartifactId=html-table-panel -Dversion=1.1 -Dpackaging=jar -DgeneratePom=true
