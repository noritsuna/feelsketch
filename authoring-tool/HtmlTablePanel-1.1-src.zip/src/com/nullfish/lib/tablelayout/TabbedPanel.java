package com.nullfish.lib.tablelayout;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.util.List;

import javax.swing.JTabbedPane;

import org.w3c.dom.Element;

public class TabbedPanel extends NodePanel {
	private JTabbedPane tabbedPane = new JTabbedPane();
	
	/**
	 * �^�O��
	 */
	public static final String TAG_NAME = "tabs";
	
	public static final String ATTR_LABEL = "label";
	
	public static final String ATTR_NAME = "name";
	
	public TabbedPanel(HtmlTableLayout owner, Element node) {
		super(owner);
		
		this.add(tabbedPane, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
		
		init(node);
	}

	public void addComponent(Component comp, String position) {
		// TODO Auto-generated method stub

	}

	public void init(Element node) {
		super.init(node);
		
		List tabNodes = XMLUtility.getChildNodeByName(node, HtmlTableLayout.TAG_COLUMN);
		for(int i=0; i<tabNodes.size(); i++) { 
			Element childNode = (Element)tabNodes.get(i);
			GridPanel child = new GridPanel(getOwner(), childNode);
			String label = childNode.getAttribute(ATTR_LABEL);
			
			tabbedPane.addTab(label, child);
		}
		
		String name = node.getAttribute(ATTR_NAME);
		if(name != null && name.length() > 0) {
			owner.setNameTabbedPanelMapping(name, this);
		}
	}
	
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}
}
